Gyakuten Saiban 1 English v0.7.57 - optional patches
=====================================================

Small add-on patches for players who prefer some things the original GBA
game's way. Everything else (script, graphics, font, sound effects, fixes)
is the same as in the main patch.

  GS1_English_v0.7.57_addon_GS1-courtroom.bps
      The first game's own courtroom: its benches, witness stand, judge's
      bench and the pans between them, instead of Gyakuten Saiban 3's.

  GS1_English_v0.7.57_addon_Japanese-voices.bps
      The Japanese voices ("Igiari!", "Matta!", "Kurae!") instead of the
      English ones. The speech bubbles stay English.

  GS1_English_v0.7.57_addon_GS1-courtroom_and_Japanese-voices.bps
      Both of the above.


How to use
----------

1. Patch your Japanese ROM with the main v0.7.57 patch, as usual
   (GS1_English_v0.7.57.bps, ..._rev1.bps or ..._tagged-dump.bps, whichever
   fits your ROM). This gives the English ROM, CRC32 1023fc28.

2. Apply ONE of these add-ons to that English ROM, with the same patcher
   (Rom Patcher JS, Floating IPS / Flips, ...).

   The add-ons only fit the English v0.7.57 ROM (CRC32 1023fc28). Applied to
   the Japanese ROM, or to an English ROM from another version, the patcher
   will refuse it (or the result won't work).

Results:

  GS1 courtroom                     CRC32 3e560167
  Japanese voices                   CRC32 6dc25835
  GS1 courtroom + Japanese voices   CRC32 30a35c4d

In-game saves work in all of them, and carry over between the main ROM and
the optional ones. Emulator savestates don't: load your in-game save instead.
